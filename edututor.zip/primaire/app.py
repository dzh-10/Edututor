import streamlit as st

st.title("Edututor")
st.write("تمارين تعليمية بالدارجة الجزائرية")
